<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Barangay Bula - Gym Reservation System</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/fullcalendar@5.11.3/main.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <link href="./style/gym.css" rel="stylesheet">
</head>
<body>
    <!-- Navigation -->
    <nav class="navbar">
        <a href="home.php" class="navbar-brand">
            <img src="./pics/logo.png" alt="Barangay Logo">
            <span> Barangay bula</span>
        </a>
    </nav>

    <!-- Main Content -->
    <div class="container">
        <div class="header">
            <h1><i class="fas fa-calendar-plus me-2"></i>Gymnasium Reservation</h1>
            <p>Book your preferred time slots for gym activities. Please select a date on the calendar to view available time slots.</p>
        </div>
        
        <div class="calendar-container">
            <div id="calendar"></div>
        </div>
        
        <div class="row">
            <div class="col-md-6 mb-4">
                <div class="card h-100">
                    <div class="card-body">
                        <h5 class="card-title"><i class="fas fa-info-circle me-2"></i>Gym Guidelines</h5>
                        <ul class="list-group list-group-flush">
                            <li class="list-group-item border-0 px-0"><i class="fas fa-check-circle text-success me-2"></i> Clean up after your session</li>
                            <li class="list-group-item border-0 px-0"><i class="fas fa-check-circle text-success me-2"></i> Bring your own equipment when possible</li>
                            <li class="list-group-item border-0 px-0"><i class="fas fa-check-circle text-success me-2"></i> No food or drinks except water</li>
                        </ul>
                    </div>
                </div>
            </div>
            <div class="col-md-6 mb-4">
                <div class="card h-100">
                    <div class="card-body">
                        <h5 class="card-title"><i class="fas fa-clock me-2"></i>Operating Hours</h5>
                        <ul class="list-group list-group-flush">
                            <li class="list-group-item border-0 px-0"><strong>Weekdays:</strong> 6:00 AM - 12:00 AM</li>
                            <li class="list-group-item border-0 px-0"><strong>Weekends:</strong> 7:00 AM - 12:00 AM</li>
                            <li class="list-group-item border-0 px-0"><strong>Holidays:</strong> 8:00 AM - 12:00 AM</li>
                            <li class="list-group-item border-0 px-0"><strong>Maintenance:</strong> Every 2nd Monday of the month</li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Time Slot Selection Modal -->
    <div class="modal fade time-slot-modal" id="timeSlotModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title"><i class="fas fa-clock me-2"></i>Select Time Slots</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                 <div class="modal-body">
                    <h6 class="selected-date-header" id="selectedDateHeader">June 15, 2025</h6>
                    <div class="time-slot-container">
                        <div class="alert alert-info">
                            <i class="fas fa-info-circle me-2"></i>
                            Select your preferred time slots below. You can select multiple slots. Rate: ₱200 per hour
                        </div>

                        <div class="availability-indicator">
                            <div class="availability-label">
                                <div class="availability-color" style="background-color: #4CAF50;"></div>
                                <span>Available</span>
                            </div>
                            <div class="availability-label">
                                <div class="availability-color" style="background-color: #2196F3;"></div>
                                <span>Selected</span>
                            </div>
                            <div class="availability-label">
                                <div class="availability-color" style="background-color: #F44336;"></div>
                                <span>Booked</span>
                            </div>
                        </div>
                        <div class="quick-select-container mb-4">
                            <span class="me-2 fw-medium">Quick Select:</span>
                            <div class="btn-group" role="group">
                                <button type="button" class="btn btn-outline-primary" id="wholeDayBtn">
                                    <i class="fas fa-calendar-day me-1"></i>Whole Day
                                </button>
                                <button type="button" class="btn btn-outline-warning" id="amHalfDayBtn">
                                    <i class="fas fa-sun me-1"></i>AM (6AM-2PM)
                                </button>
                                <button type="button" class="btn btn-outline-info" id="pmHalfDayBtn">
                                    <i class="fas fa-moon me-1"></i>PM (2PM-12AM)
                                </button>
                            </div>
                        </div>
                        
                        <div class="time-slot-grid" id="time-slots-container">
                            <!-- Time slots will be dynamically generated here -->
                        </div>
                        
                        <div class="selected-slots-summary" id="selectedSlotsSummary" style="display: none;">
                            <h6><i class="fas fa-check-circle me-2"></i>Selected Time Slots:</h6>
                            <div id="selectedSlotsList" class="mt-2"></div>
                            <div class="mt-2 fw-bold">Estimated Total: <span id="estimatedTotal">₱0</span></div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">
                        <i class="fas fa-times me-1"></i> Cancel
                    </button>
                    <button type="button" class="btn btn-primary" id="proceedToReservation" disabled>
                        <i class="fas fa-arrow-right me-1"></i> Continue
                    </button>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Reservation Form Modal -->
    <div class="modal fade reservation-form-modal" id="reservationFormModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title"><i class="fas fa-calendar-check me-2"></i>Complete Your Reservation</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <div class="alert alert-info">
                        <i class="fas fa-info-circle me-2"></i>
                        You're reserving the gym on <strong id="reservationDateDisplay"></strong> for:
                        <ul id="reservationTimesDisplay" class="mt-2 mb-0"></ul>
                        <div class="mt-2">Total: <strong id="reservationTotalDisplay">₱0</strong></div>
                    </div>
                    
                    <div class="reference-number">
                        <i class="fas fa-tag"></i>
                        <span>Reference: <strong id="referenceNumberDisplay"></strong></span>
                    </div>
                    
                    <form id="reservationForm">
                        <input type="hidden" id="reservationDate">
                        <input type="hidden" id="selectedSlots">
                        <input type="hidden" id="referenceNumber">
                        
                        <div class="form-section">
                            <h6><i class="fas fa-user me-2"></i>Resident Information</h6>
                            <div class="row g-3">
                                <div class="col-md-6">
                                    <label for="residentName" class="form-label">Full Name</label>
                                    <input type="text" class="form-control" id="residentName" required>
                                </div>
                                <div class="col-md-6">
                                    <label for="contactNumber" class="form-label">Contact Number</label>
                                    <input type="tel" class="form-control" id="contactNumber" required>
                                </div>
                            </div>
                        </div>
                        
                        <div class="form-section">
                            <h6><i class="fas fa-running me-2"></i>Activity Details</h6>
                            <div class="row g-3">
                                <div class="col-md-12">
                                    <label for="activityType" class="form-label">Activity Type</label>
                                    <input type="text" class="form-control" id="activityType" required placeholder="e.g. Basketball Practice, Zumba Class">
                                </div>
                                <div class="col-md-6">
                                    <label for="participantCount" class="form-label">Number of Participants</label>
                                    <input type="number" class="form-control" id="participantCount" min="1" required>
                                </div>
                            </div>
                            <div class="mt-3">
                                <label for="reservationNotes" class="form-label">Additional Notes</label>
                                <textarea class="form-control" id="reservationNotes" rows="3" placeholder="Any special requests or requirements"></textarea>
                            </div>
                        </div>
                        
                        <div class="alert alert-warning mt-4">
                            <i class="fas fa-exclamation-triangle me-2"></i>
                            By submitting this form, you agree to the <a href="#" class="alert-link">gymnasium usage rules and policies</a>.
                        </div>
                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">
                        <i class="fas fa-times me-1"></i> Cancel
                    </button>
                    <button type="button" class="btn btn-primary" id="submitReservation">
                        <i class="fas fa-paper-plane me-1"></i> Submit Request
                    </button>
                </div>
            </div>
        </div>
    </div>

    <!-- Confirmation Modal -->
    <div class="modal fade confirmation-modal" id="confirmationModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Reservation Submitted</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body text-center">
                    <div class="confirmation-icon text-success">
                        <i class="fas fa-check-circle fa-5x"></i>
                    </div>
                    <h4 class="my-3">Reservation Submitted for Approval!</h4>
                    
                    <div class="alert alert-info text-start">
                        <h5><i class="fas fa-info-circle me-2"></i>Next Steps:</h5>
                        <ol class="mb-0">
                            <li>Wait for admin approval (we'll SMS you)</li>
                            <li>If approved, pay ₱<span id="confirmedAmount"></span> at Barangay Hall</li>
                            <li>Bring this reference number: <strong id="confirmedReference"></strong></li>
                        </ol>
                    </div>
                    
                    <div class="d-flex justify-content-center gap-2 mt-4">
                        <button class="btn btn-outline-primary" onclick="window.print()">
                            <i class="fas fa-print me-1"></i> Print
                        </button>
                        <button class="btn btn-primary" data-bs-dismiss="modal">
                            <i class="fas fa-check me-1"></i> Understood
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/fullcalendar@5.11.3/main.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/js/all.min.js"></script>
    <script src="./script/gym.js"></script>
</body>
</html>