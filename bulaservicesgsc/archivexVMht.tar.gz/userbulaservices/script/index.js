document.addEventListener('DOMContentLoaded', function() {
    // Profile Picture Preview
    document.getElementById('profilePictureInput')?.addEventListener('change', function(e) {
        const file = e.target.files[0];
        if (file) {
            const reader = new FileReader();
            reader.onload = function(event) {
                const profileImage = document.getElementById('profileImage');
                profileImage.src = event.target.result;
                profileImage.style.display = 'block';
            };
            reader.readAsDataURL(file);
        }
    });

    // Resident Fields Toggle
    const setupResidentFieldsToggle = () => {
        const residentRadio = document.querySelector('input[name="resident_status"][value="resident"]');
        const outsiderRadio = document.querySelector('input[name="resident_status"][value="outsider"]');
        const residentOnlyFields = document.querySelectorAll('.resident-only-field');

        const toggleResidentFields = () => {
            const isResident = residentRadio?.checked;
            residentOnlyFields.forEach(field => {
                field.style.display = isResident ? 'block' : 'none';
                if (!isResident) {
                    const inputs = field.querySelectorAll('input, select');
                    inputs.forEach(input => input.required = false);
                }
            });
        };

        if (residentRadio && outsiderRadio) {
            residentRadio.addEventListener('change', toggleResidentFields);
            outsiderRadio.addEventListener('change', toggleResidentFields);
            toggleResidentFields();
        }
    };
    setupResidentFieldsToggle();

    // Tab Switching
    const tabSwitching = () => {
        document.querySelectorAll('.tab').forEach(tab => {
            tab.addEventListener('click', function() {
                const tabId = this.getAttribute('data-tab');
                document.querySelectorAll('.tab').forEach(t => t.classList.remove('active'));
                this.classList.add('active');
                document.querySelectorAll('.tab-content').forEach(c => c.classList.remove('active'));
                document.getElementById(tabId).classList.add('active');
            });
        });
    };
    tabSwitching();

    // Registration Form Submission
    const registerForm = document.getElementById('registerForm');
    if (registerForm) {
        registerForm.addEventListener('submit', async function(e) {
            e.preventDefault();
            
            const form = e.target;
            const formData = new FormData(form);
            const submitBtn = form.querySelector('button[type="submit"]');
            const originalBtnText = submitBtn.textContent;
            
            // Show loading state
            submitBtn.disabled = true;
            submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Registering...';
            
            // Clear previous errors
            document.querySelectorAll('.error-text').forEach(el => el.remove());

            try {
                const response = await fetch('./php/index.php', {
                    method: 'POST',
                    body: formData
                });

                const responseText = await response.text(); 
                console.log('Raw Response:', responseText); 

                let data;
                try {
                    data = JSON.parse(responseText);
                } catch (parseError) {
                    console.error('Failed to parse JSON:', parseError);
                    showAlert('error', 'Invalid server response. Please check PHP backend.');
                    resetSubmitButton(submitBtn, originalBtnText);
                    return;
                }

                if (data.success) {
                    showAlert('success', data.message);
                    form.reset();
                    document.getElementById('profileImage').src = './pics/profile-placeholder.jpg';
                    document.querySelector('.tab[data-tab="login"]').click();
                    document.getElementById('loginEmail').value = data.email || '';
                } else {
                    // Show error messages
                    showFormErrors(data.errors);
                    showAlert('error', data.message || 'Registration failed');
                }
            } catch (error) {
                console.error('Error:', error);
                showAlert('error', 'An error occurred. Please try again.');
            } finally {
                resetSubmitButton(submitBtn, originalBtnText);
            }
        });
    }

   // Login Form Submission (database-based)
const loginForm = document.getElementById('loginForm');
if (loginForm) {
    loginForm.addEventListener('submit', async function(e) {
        e.preventDefault();

        const formData = new FormData(loginForm);
        formData.append("login", "1"); // flag for backend

        const submitBtn = e.target.querySelector('button[type="submit"]');
        const originalBtnText = submitBtn.textContent;

        // Show loading state
        submitBtn.disabled = true;
        submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Logging in...';

        try {
            const response = await fetch('./php/index.php', {
                method: 'POST',
                body: formData
            });

            const responseText = await response.text();
            console.log('Login Raw Response:', responseText);

            let data;
            try {
                data = JSON.parse(responseText);
            } catch (parseError) {
                console.error('Failed to parse login JSON:', parseError);
                showAlert('error', 'Invalid server response. Please check PHP backend.');
                return;
            }

            if (data.success) {
                window.location.href = data.redirect;
            } else {
                showAlert('error', data.message || 'Invalid email or password');
            }
        } catch (error) {
            console.error('Login Error:', error);
            showAlert('error', 'An error occurred. Please try again.');
        } finally {
            submitBtn.disabled = false;
            submitBtn.textContent = originalBtnText;
        }
    });
}

    // Helper function to show alerts
    function showAlert(type, message) {
        const alertDiv = document.createElement('div');
        alertDiv.className = `alert alert-${type}`;
        alertDiv.textContent = message;

        const authBody = document.querySelector('.auth-body');
        authBody.prepend(alertDiv);

        setTimeout(() => alertDiv.remove(), 5000);
    }

    // Helper function to show form field errors
    function showFormErrors(errors) {
        if (errors) {
            for (const [field, message] of Object.entries(errors)) {
                const input = document.querySelector(`[name="${field}"]`);
                if (input) {
                    const error = document.createElement('div');
                    error.className = 'error-text';
                    error.textContent = message;
                    input.closest('.form-group').appendChild(error);
                    input.focus();
                }
            }
        }
    }

    // Helper function to reset submit button
    function resetSubmitButton(button, originalText) {
        button.disabled = false;
        button.textContent = originalText;
    }

    // Date picker initialization
    const birthDateInput = document.getElementById('birthDate');
    if (birthDateInput) {
        birthDateInput.addEventListener('focus', function() {
            this.type = 'date';
        });
        birthDateInput.addEventListener('blur', function() {
            if (!this.value) this.type = 'text';
        });
    }
});
