document.addEventListener('DOMContentLoaded', function() {
    // Initialize modals
    const timeSlotModal = new bootstrap.Modal(document.getElementById('timeSlotModal'));
    const reservationModal = new bootstrap.Modal(document.getElementById('reservationFormModal'));
    const confirmationModal = new bootstrap.Modal(document.getElementById('confirmationModal'));

    // Store selections
    let selectedDate = '';
    let selectedSlots = [];
    let activeQuickSelect = null;
    let calendar;

    // Initialize Calendar
    function initCalendar() {
        const calendarEl = document.getElementById('calendar');
        calendar = new FullCalendar.Calendar(calendarEl, {
            initialView: 'dayGridMonth',
            headerToolbar: {
                left: 'prev,next today',
                center: 'title',
                right: 'dayGridMonth,timeGridWeek,timeGridDay'
            },
            height: 'auto',
            dateClick: handleDateClick,
            events: [],
            eventDisplay: 'block',
            eventTimeFormat: {
                hour: '2-digit',
                minute: '2-digit',
                hour12: true
            },
            dayMaxEvents: 2,
            validRange: {
                start: new Date()
            },
            nowIndicator: true
        });
        
        calendar.render();
        return calendar;
    }

    // Calendar date click handler
    function handleDateClick(info) {
        const clickedDate = new Date(info.dateStr);
        if (clickedDate < new Date()) {
            alert('You cannot book dates in the past.');
            return;
        }
        
        selectedDate = info.dateStr;
        updateSelectedDateHeader(selectedDate);
        loadTimeSlots(selectedDate);
        timeSlotModal.show();
        activeQuickSelect = null;
        updateButtonStates();
    }

    function updateSelectedDateHeader(dateStr) {
        const date = new Date(dateStr);
        document.getElementById('selectedDateHeader').textContent = 
            date.toLocaleDateString('en-US', { 
                weekday: 'long', 
                year: 'numeric', 
                month: 'long', 
                day: 'numeric' 
            });
    }

    function loadTimeSlots(date) {
        const container = document.getElementById('time-slots-container');
        container.innerHTML = '';
        selectedSlots = [];
        document.getElementById('proceedToReservation').disabled = true;
        document.getElementById('selectedSlotsSummary').style.display = 'none';
        
        const startHour = 6; // Opening hour
        const endHour = 24; // Closing hour
        
        for (let hour = startHour; hour < endHour; hour++) {
            const nextHour = hour + 1;
            if (nextHour > endHour) break;
            
            const displayHour = hour > 12 ? hour - 12 : hour;
            const nextDisplayHour = nextHour > 12 ? nextHour - 12 : nextHour;
            const ampm = hour >= 12 ? 'PM' : 'AM';
            const nextAmpm = nextHour >= 12 ? 'PM' : 'AM';
            
            const timeRange = `${displayHour}:00 ${ampm} - ${nextDisplayHour}:00 ${nextAmpm}`;
            const timeDisplay = `${displayHour}:00${ampm} - ${nextDisplayHour}:00${nextAmpm}`;
            
            const isBooked = false; // In real app, would check against booked slots
            
            const card = document.createElement('div');
            card.className = `time-slot-card ${isBooked ? 'booked' : ''}`;
            card.dataset.hour = hour;
            
            const timeElement = document.createElement('div');
            timeElement.className = 'time-slot-range';
            timeElement.textContent = timeDisplay;
            card.appendChild(timeElement);
            
            card.setAttribute('data-bs-toggle', 'tooltip');
            card.setAttribute('data-bs-placement', 'top');
            card.setAttribute('title', isBooked ? 
                `This slot is already booked` : 
                `Available for booking`);
            
            if (!isBooked) {
                card.addEventListener('click', function() {
                    toggleSlotSelection(card, {
                        hour: hour,
                        time: timeRange,
                        booked: isBooked
                    });
                    activeQuickSelect = null;
                    updateButtonStates();
                });
            }
            
            container.appendChild(card);
        }
        
        // Initialize tooltips
        const tooltipTriggerList = [].slice.call(container.querySelectorAll('[data-bs-toggle="tooltip"]'));
        const tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
            return new bootstrap.Tooltip(tooltipTriggerEl);
        });
    }
    
    function toggleSlotSelection(card, slot) {
        const index = selectedSlots.findIndex(s => s.hour === slot.hour);
        
        if (index === -1) {
            selectedSlots.push(slot);
            card.classList.add('selected');
        } else {
            selectedSlots.splice(index, 1);
            card.classList.remove('selected');
        }
        
        updateSelectedSlotsSummary();
        document.getElementById('proceedToReservation').disabled = selectedSlots.length === 0;
    }
    
    function updateSelectedSlotsSummary() {
        const summary = document.getElementById('selectedSlotsSummary');
        const list = document.getElementById('selectedSlotsList');
        const totalElement = document.getElementById('estimatedTotal');
        
        if (selectedSlots.length > 0) {
            summary.style.display = 'block';
            list.innerHTML = selectedSlots.map(slot => 
                `<div>• ${slot.time}</div>`
            ).join('');
            
            const totalAmount = selectedSlots.length * 200; // ₱200 per hour
            totalElement.textContent = `₱${totalAmount}`;
        } else {
            summary.style.display = 'none';
            totalElement.textContent = '₱0';
        }
    }
    
    function generateReferenceNumber() {
        const letters = 'ABCDEFGHJKLMNPQRSTUVWXYZ';
        const numbers = '0123456789';
        let result = 'GYM-';
        
        for (let i = 0; i < 3; i++) {
            result += letters.charAt(Math.floor(Math.random() * letters.length));
        }
        
        for (let i = 0; i < 4; i++) {
            result += numbers.charAt(Math.floor(Math.random() * numbers.length));
        }
        
        return result;
    }

    // Quick-select buttons
    function setupQuickSelectButtons() {
        const buttons = {
            wholeDayBtn: { start: 6, end: 24 },
            amHalfDayBtn: { start: 6, end: 14 },
            pmHalfDayBtn: { start: 14, end: 24 }
        };

        Object.keys(buttons).forEach(buttonId => {
            const btn = document.getElementById(buttonId);
            if (btn) {
                btn.addEventListener('click', () => {
                    if (activeQuickSelect === buttonId) {
                        clearSelection();
                        activeQuickSelect = null;
                    } else {
                        const range = buttons[buttonId];
                        selectTimeRange(range.start, range.end);
                        activeQuickSelect = buttonId;
                    }
                    updateButtonStates();
                });
            }
        });
    }

    function updateButtonStates() {
        ['wholeDayBtn', 'amHalfDayBtn', 'pmHalfDayBtn'].forEach(id => {
            const btn = document.getElementById(id);
            if (btn) btn.classList.toggle('active', id === activeQuickSelect);
        });
    }

    function clearSelection() {
        selectedSlots = [];
        document.querySelectorAll('.time-slot-card.selected').forEach(card => {
            card.classList.remove('selected');
        });
        updateSelectedSlotsSummary();
        document.getElementById('proceedToReservation').disabled = true;
    }

    function selectTimeRange(startHour, endHour) {
        clearSelection();
        
        const allSlots = Array.from(document.querySelectorAll('.time-slot-card:not(.booked)'));
        const slotsInRange = allSlots.filter(slot => {
            const slotHour = parseInt(slot.dataset.hour);
            return slotHour >= startHour && slotHour < endHour;
        });
        
        slotsInRange.forEach(slot => {
            if (!slot.classList.contains('booked')) {
                slot.classList.add('selected');
                const hour = parseInt(slot.dataset.hour);
                const timeDisplay = slot.querySelector('.time-slot-range').textContent;
                
                selectedSlots.push({
                    hour: hour,
                    time: timeDisplay.replace(/(\d+:\d+[AP]M) - (\d+:\d+[AP]M)/, '$1 $2'),
                    booked: false
                });
            }
        });
        
        updateSelectedSlotsSummary();
        document.getElementById('proceedToReservation').disabled = selectedSlots.length === 0;
    }

    // Main flow
    document.getElementById('proceedToReservation').addEventListener('click', function() {
        const dateObj = new Date(selectedDate);
        document.getElementById('reservationDateDisplay').textContent = 
            dateObj.toLocaleDateString('en-US', { 
                weekday: 'long', 
                year: 'numeric', 
                month: 'long', 
                day: 'numeric' 
            });
        
        document.getElementById('reservationTimesDisplay').innerHTML = selectedSlots.map(slot => 
            `<li>${slot.time}</li>`
        ).join('');
        
        document.getElementById('reservationTotalDisplay').textContent = 
            `₱${selectedSlots.length * 200}`;
        
        document.getElementById('reservationDate').value = selectedDate;
        document.getElementById('selectedSlots').value = JSON.stringify(selectedSlots);
        
        const refNumber = generateReferenceNumber();
        document.getElementById('referenceNumberDisplay').textContent = refNumber;
        document.getElementById('referenceNumber').value = refNumber;
        
        timeSlotModal.hide();
        reservationModal.show();
    });

    document.getElementById('submitReservation').addEventListener('click', function() {
        const form = document.getElementById('reservationForm');
        
        if (form.checkValidity()) {
            // In a real app, would submit to server here
            console.log('Reservation submitted:', {
                date: selectedDate,
                slots: selectedSlots,
                resident: document.getElementById('residentName').value,
                contact: document.getElementById('contactNumber').value,
                activity: document.getElementById('activityType').value,
                participants: document.getElementById('participantCount').value,
                notes: document.getElementById('reservationNotes').value,
                reference: document.getElementById('referenceNumber').value
            });
            
            // Update confirmation modal
            document.getElementById('confirmedReference').textContent = 
                document.getElementById('referenceNumber').value;
            document.getElementById('confirmedAmount').textContent = 
                selectedSlots.length * 200;
            
            reservationModal.hide();
            confirmationModal.show();
            
            // Clear form
            form.reset();
        } else {
            form.reportValidity();
        }
    });

    function convertTo24HourFormat(timeStr) {
        const [time, period] = timeStr.split(' ');
        let [hours, minutes] = time.split(':');
        
        if (period === 'PM' && hours !== '12') {
            hours = parseInt(hours, 10) + 12;
        } else if (period === 'AM' && hours === '12') {
            hours = '00';
        }
        
        return `${hours}:${minutes}`;
    }

    // Initialize all components
    calendar = initCalendar();
    setupQuickSelectButtons();
});