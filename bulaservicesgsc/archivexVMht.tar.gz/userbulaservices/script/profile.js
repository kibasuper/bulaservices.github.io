// Mock user data - This will be replaced with real API calls later
const mockUser = {
    firstName: "Juan",
    middleName: "Mendoza",
    lastName: "Dela Cruz",
    placeOfBirth: "General Santos City",
    birthDate: "1990-06-15",
    civilStatus: "Single",
    sex: "Male",
    yearStarted: 2015,
    contactNumber: "09123456789",
    occupation: "Fisherman",
    address: "123 Bula Street, General Santos City",
    profilePic: "./pics/profile-placeholder.jpg"
};

// Initialize the profile page
document.addEventListener('DOMContentLoaded', function() {
    loadProfileData();
    
    // Profile picture upload
    document.getElementById('editPicBtn').addEventListener('click', function() {
        document.getElementById('profilePicInput').click();
    });
    
    document.getElementById('profilePicInput').addEventListener('change', function(e) {
        if (e.target.files && e.target.files[0]) {
            const reader = new FileReader();
            
            reader.onload = function(event) {
                document.getElementById('profileImage').src = event.target.result;
                mockUser.profilePic = event.target.result;
                updateLocalStorage();
            };
            
            reader.readAsDataURL(e.target.files[0]);
        }
    });

    // Save All Changes Button
    document.getElementById('saveAllBtn').addEventListener('click', function() {
        alert('All changes saved successfully!');
        // In real implementation: Send all data to backend
    });
});

function loadProfileData() {
    // Load from localStorage or use mock data
    const savedData = localStorage.getItem('barangayProfileData');
    const userData = savedData ? JSON.parse(savedData) : mockUser;
    
    // Calculate age
    const age = calculateAge(userData.birthDate);
    
    // Set all field values
    updateProfileName(userData);
    document.getElementById('profileImage').src = userData.profilePic;
    
    // Personal Information
    document.getElementById('firstNameValue').textContent = userData.firstName;
    document.getElementById('middleNameValue').textContent = userData.middleName;
    document.getElementById('lastNameValue').textContent = userData.lastName;
    document.getElementById('placeOfBirthValue').textContent = userData.placeOfBirth;
    document.getElementById('birthDateValue').textContent = formatDate(userData.birthDate);
    document.getElementById('ageValue').textContent = `${age} years old`;
    document.getElementById('sexValue').textContent = userData.sex;
    document.getElementById('civilStatusValue').textContent = userData.civilStatus;
    
    // Residence Information
    document.getElementById('yearStartedValue').textContent = userData.yearStarted;
    document.getElementById('contactNumberValue').textContent = userData.contactNumber;
    document.getElementById('occupationValue').textContent = userData.occupation;
    document.getElementById('addressValue').textContent = userData.address;
    
    // Set select values
    document.getElementById('sexInput').value = userData.sex;
    document.getElementById('civilStatusInput').value = userData.civilStatus;
}

function updateProfileName(userData) {
    const middleInitial = userData.middleName ? `${userData.middleName.charAt(0)}. ` : '';
    document.getElementById('profileName').textContent = 
        `${userData.firstName} ${middleInitial}${userData.lastName}`;
}

function calculateAge(birthDate) {
    const birth = new Date(birthDate);
    const today = new Date();
    let age = today.getFullYear() - birth.getFullYear();
    const monthDiff = today.getMonth() - birth.getMonth();
    
    if (monthDiff < 0 || (monthDiff === 0 && today.getDate() < birth.getDate())) {
        age--;
    }
    
    return age;
}

function formatDate(dateString) {
    const options = { year: 'numeric', month: 'long', day: 'numeric' };
    return new Date(dateString).toLocaleDateString('en-US', options);
}

function toggleEdit(field) {
    const valueElement = document.getElementById(`${field}Value`);
    const formElement = document.getElementById(`${field}Form`);
    
    // Hide all other edit forms first
    document.querySelectorAll('.edit-form').forEach(form => {
        if (form.id !== `${field}Form`) {
            form.style.display = 'none';
        }
    });
    
    // Toggle current form
    if (formElement.style.display === 'block') {
        formElement.style.display = 'none';
    } else {
        formElement.style.display = 'block';
        
        // Special handling for different field types
        const inputElement = document.getElementById(`${field}Input`);
        if (field === 'birthDate') {
            inputElement.value = mockUser.birthDate;
        } else if (field === 'yearStarted') {
            inputElement.value = mockUser.yearStarted;
        } else {
            inputElement.value = mockUser[field] || valueElement.textContent;
        }
    }
}

function cancelEdit(field) {
    document.getElementById(`${field}Form`).style.display = 'none';
}

function saveField(field) {
    const inputElement = document.getElementById(`${field}Input`);
    const newValue = inputElement.value;
    
    // Update mock data
    mockUser[field] = newValue;
    
    // Special handling for birthdate (update age)
    if (field === 'birthDate') {
        const formattedDate = formatDate(newValue);
        document.getElementById('birthDateValue').textContent = formattedDate;
        const age = calculateAge(newValue);
        document.getElementById('ageValue').textContent = `${age} years old`;
        mockUser.birthDate = newValue; // Store in ISO format
    } else {
        document.getElementById(`${field}Value`).textContent = newValue;
    }
    
    // Update profile name if name fields changed
    if (['firstName', 'middleName', 'lastName'].includes(field)) {
        updateProfileName(mockUser);
    }
    
    // Hide form
    document.getElementById(`${field}Form`).style.display = 'none';
    
    // Update localStorage
    updateLocalStorage();
}

function updateLocalStorage() {
    localStorage.setItem('barangayProfileData', JSON.stringify(mockUser));
}

function changePassword() {
    const currentPassword = document.getElementById('currentPassword').value;
    const newPassword = document.getElementById('newPassword').value;
    const confirmPassword = document.getElementById('confirmPassword').value;
    
    // Basic validation
    if (!currentPassword || !newPassword || !confirmPassword) {
        alert('Please fill in all password fields!');
        return;
    }
    
    if (newPassword !== confirmPassword) {
        alert('New passwords do not match!');
        return;
    }
    
    if (newPassword.length < 8) {
        alert('Password must be at least 8 characters long!');
        return;
    }
    
    if (!/\d/.test(newPassword)) {
        alert('Password must contain at least one number!');
        return;
    }
    
    // In a real app, you would verify current password with server
    alert('Password changed successfully!');
    
    // Clear fields
    document.getElementById('currentPassword').value = '';
    document.getElementById('newPassword').value = '';
    document.getElementById('confirmPassword').value = '';
}