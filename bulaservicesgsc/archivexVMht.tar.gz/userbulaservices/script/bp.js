// Helper function to generate reference number
function generateReferenceNumber() {
    const now = new Date();
    // Get date in YYYYMMDD format (Philippine time)
    const date = now.toLocaleDateString('en-CA', { 
        timeZone: 'Asia/Manila',
        year: 'numeric',
        month: '2-digit',
        day: '2-digit'
    }).replace(/-/g, '');
    
    // Generate 3-digit random number (000-999)
    const random = Math.floor(Math.random() * 1000).toString().padStart(3, '0');
    
    return `BP-${date}-${random}`;
}

// Calculate business permit fee based on number of copies
function calculateFee() {
    const quantity = parseInt(document.getElementById('copyQuantity').value) || 1;
    const fee = quantity * 80;
    document.getElementById('calculatedFee').textContent = fee.toFixed(2);
}

// Validate Philippine phone number
function validatePhoneNumber(phone) {
    const regex = /^(09|\+639)\d{9}$/;
    return regex.test(phone);
}

// Validate form section
function validateSection(sectionId) {
    let isValid = true;
    const section = document.getElementById(sectionId);
    
    // Validate required fields in this section
    const requiredInputs = section.querySelectorAll('[required]');
    requiredInputs.forEach(input => {
        if (!input.value.trim()) {
            input.classList.add('has-error');
            const errorId = input.id + 'Error';
            if (document.getElementById(errorId)) {
                document.getElementById(errorId).style.display = 'block';
            }
            isValid = false;
        } else {
            input.classList.remove('has-error');
            const errorId = input.id + 'Error';
            if (document.getElementById(errorId)) {
                document.getElementById(errorId).style.display = 'none';
            }
        }
    });
    
    // Special validation for business type "Other"
    if (sectionId === 'section2' && document.getElementById('businessType').value === 'Other') {
        if (!document.getElementById('otherBusinessType').value.trim()) {
            document.getElementById('otherBusinessTypeError').style.display = 'block';
            document.getElementById('otherBusinessType').classList.add('has-error');
            isValid = false;
        } else {
            document.getElementById('otherBusinessTypeError').style.display = 'none';
            document.getElementById('otherBusinessType').classList.remove('has-error');
        }
    }
    
    // Validate clearance method
    if (sectionId === 'section3') {
        const clearanceMethod = document.querySelector('input[name="clearanceMethod"]:checked');
        if (!clearanceMethod) {
            document.getElementById('clearanceMethodError').style.display = 'block';
            isValid = false;
        } else {
            document.getElementById('clearanceMethodError').style.display = 'none';
            
            // Validate file upload if that method was selected
            if (clearanceMethod.value === 'upload' && !document.getElementById('purokClearance').files[0]) {
                document.getElementById('fileUploadError').style.display = 'block';
                isValid = false;
            } else {
                document.getElementById('fileUploadError').style.display = 'none';
            }
        }
    }
    
    return isValid;
}

// Global functions
function selectClearanceOption(method) {
    // Update radio button selection
    document.getElementById(method + 'Option').checked = true;
    
    // Update visual selection
    document.querySelectorAll('.clearance-option').forEach(option => {
        option.classList.remove('active');
        option.setAttribute('aria-pressed', 'false');
    });
    event.currentTarget.classList.add('active');
    event.currentTarget.setAttribute('aria-pressed', 'true');
    
    // Show/hide appropriate sections
    document.getElementById('uploadContainer').style.display = 
        method === 'upload' ? 'block' : 'none';
    document.getElementById('hallInfo').style.display = 
        method === 'hall' ? 'block' : 'none';
        
    // Set required attribute based on selection
    document.getElementById('purokClearance').required = 
        method === 'upload';
}

// DOM Content Loaded
document.addEventListener('DOMContentLoaded', function() {
    // In a real implementation, you would load this from your database
    const currentUser = {
        fullName: 'Juan Dela Cruz',
        contactNumber: '09123456789',
        address: '123 Bula Street, Purok 5, Barangay Bula',
        yearOfStay: '2015',
        email: 'juan.delacruz@example.com'
    };
    
    // Display user data
    document.getElementById('fullName').value = currentUser.fullName;
    document.getElementById('contactNumber').value = currentUser.contactNumber;
    document.getElementById('address').value = currentUser.address;
    document.getElementById('yearOfStay').value = currentUser.yearOfStay;
    
    // Handle purpose selection
    document.getElementById('purpose').addEventListener('change', function() {
        const otherContainer = document.getElementById('otherPurposeContainer');
        otherContainer.style.display = this.value === 'Other' ? 'block' : 'none';
        if (this.value === 'Other') {
            document.getElementById('otherPurpose').required = true;
        } else {
            document.getElementById('otherPurpose').required = false;
        }
    });
    
    // Handle business type selection
    document.getElementById('businessType').addEventListener('change', function() {
        const otherContainer = document.getElementById('otherBusinessTypeContainer');
        otherContainer.style.display = this.value === 'Other' ? 'block' : 'none';
        if (this.value === 'Other') {
            document.getElementById('otherBusinessType').required = true;
        } else {
            document.getElementById('otherBusinessType').required = false;
        }
    });
    
    // Handle file upload display
    document.getElementById('purokClearance').addEventListener('change', function(e) {
        const file = e.target.files[0];
        if (file) {
            // Validate file size (max 5MB)
            if (file.size > 5 * 1024 * 1024) {
                document.getElementById('fileUploadError').textContent = 'File size exceeds 5MB limit';
                document.getElementById('fileUploadError').style.display = 'block';
                e.target.value = '';
                document.getElementById('fileName').textContent = 'No file chosen';
                return;
            }
            
            // Validate file type
            const validTypes = ['image/jpeg', 'image/png', 'application/pdf'];
            if (!validTypes.includes(file.type)) {
                document.getElementById('fileUploadError').textContent = 'Invalid file type. Please upload JPG, PNG, or PDF';
                document.getElementById('fileUploadError').style.display = 'block';
                e.target.value = '';
                document.getElementById('fileName').textContent = 'No file chosen';
                return;
            }
            
            document.getElementById('fileName').textContent = file.name;
            document.getElementById('fileUploadError').style.display = 'none';
        } else {
            document.getElementById('fileName').textContent = 'No file chosen';
        }
    });
    
    // Handle copy quantity change
    document.getElementById('copyQuantity').addEventListener('change', calculateFee);
    document.getElementById('copyQuantity').addEventListener('input', calculateFee);
    
    // Navigation between form sections
    document.getElementById('nextBtn1').addEventListener('click', function() {
        if (validateSection('section1')) {
            document.getElementById('section1').classList.remove('active');
            document.getElementById('section2').classList.add('active');
            document.getElementById('step1').classList.remove('active');
            document.getElementById('step1').classList.add('completed');
            document.getElementById('step2').classList.add('active');
            document.getElementById('section2').focus();
        }
    });
    
    document.getElementById('nextBtn2').addEventListener('click', function() {
        if (validateSection('section2')) {
            document.getElementById('section2').classList.remove('active');
            document.getElementById('section3').classList.add('active');
            document.getElementById('step2').classList.remove('active');
            document.getElementById('step2').classList.add('completed');
            document.getElementById('step3').classList.add('active');
            document.getElementById('section3').focus();
        }
    });
    
    document.getElementById('prevBtn1').addEventListener('click', function() {
        document.getElementById('section2').classList.remove('active');
        document.getElementById('section1').classList.add('active');
        document.getElementById('step1').classList.add('active');
        document.getElementById('step2').classList.remove('active');
        document.getElementById('step2').classList.remove('completed');
        document.getElementById('section1').focus();
    });
    
    document.getElementById('prevBtn2').addEventListener('click', function() {
        document.getElementById('section3').classList.remove('active');
        document.getElementById('section2').classList.add('active');
        document.getElementById('step2').classList.add('active');
        document.getElementById('step3').classList.remove('active');
        document.getElementById('step3').classList.remove('completed');
        document.getElementById('section2').focus();
    });
    
    // Cancel button functionality
    document.getElementById('cancelBtn').addEventListener('click', function() {
        if (confirm('Are you sure you want to cancel? Any unsaved changes will be lost.')) {
            window.location.href = 'home.php';
        }
    });
    
    // Handle form submission
    document.getElementById('businessPermitForm').addEventListener('submit', function(e) {
        e.preventDefault();
        
        // Validate final section
        if (!validateSection('section3')) {
            return;
        }
        
        // Show loading state
        const submitBtn = document.getElementById('submitApplication');
        submitBtn.disabled = true;
        submitBtn.innerHTML = '<span class="spinner"></span> Submitting...';
        
        // Simulate API call delay
        setTimeout(function() {
            // Generate reference number
            const refNumber = generateReferenceNumber();
            document.getElementById('referenceNumber').textContent = refNumber;
            
            // Show success modal
            const successModal = document.getElementById('successModal');
            successModal.style.display = 'block';
            
            // Prevent scrolling when modal is open
            document.body.style.overflow = 'hidden';
            
            // Reset form and buttons
            submitBtn.disabled = false;
            submitBtn.innerHTML = '<i class="fas fa-paper-plane"></i> Submit Application';
        }, 1500);
    });
    
    // Close modal handlers
    document.querySelector('.close-modal').addEventListener('click', function() {
        document.getElementById('successModal').style.display = 'none';
        document.body.style.overflow = 'auto';
        window.location.href = 'home.php'; // Redirect to home page
    });
    
    document.getElementById('closeModalBtn').addEventListener('click', function() {
        document.getElementById('successModal').style.display = 'none';
        document.body.style.overflow = 'auto';
        window.location.href = 'home.php'; // Redirect to home page
    });
    
    // Close when clicking outside modal
    window.addEventListener('click', function(event) {
        const successModal = document.getElementById('successModal');
        if (event.target === successModal) {
            successModal.style.display = 'none';
            document.body.style.overflow = 'auto';
            window.location.href = 'home.php'; // Redirect to home page
        }
    });
    
    // Keyboard navigation for clearance options
    document.querySelectorAll('.clearance-option').forEach(option => {
        option.addEventListener('keydown', function(e) {
            if (e.key === 'Enter' || e.key === ' ') {
                e.preventDefault();
                const method = this.querySelector('input').value;
                selectClearanceOption(method);
            }
        });
    });
    
    // Initial fee calculation
    calculateFee();
});