// Profile dropdown functionality
document.addEventListener('DOMContentLoaded', function() {
    const profileBtn = document.querySelector('.profile-btn');
    const dropdownMenu = document.getElementById('dropdownMenu');
    
    // Set profile picture if available
    const profilePic = document.querySelector('.profile-pic');
    if (currentUser.profilePic) {
        profilePic.src = currentUser.profilePic;
    }
    
    // Add logout functionality
    document.getElementById('logoutLink').addEventListener('click', function(e) {
        e.preventDefault();
        localStorage.removeItem('currentUser');
        window.location.href = "index.php";
    });
    
    // Toggle dropdown when profile button is clicked
    profileBtn.addEventListener('click', function(e) {
        e.stopPropagation();
        dropdownMenu.classList.toggle('show');
    });
    
    // Close dropdown when clicking outside
    document.addEventListener('click', function() {
        dropdownMenu.classList.remove('show');
    });
    
    // Prevent dropdown from closing when clicking inside it
    dropdownMenu.addEventListener('click', function(e) {
        e.stopPropagation();
    });
    
    // Initialize carousel
    initCarousel();
    
    // Form submission
    const contactForm = document.getElementById('contactForm');
    contactForm.addEventListener('submit', function(e) {
        e.preventDefault();
        alert('Thank you for your message! We will get back to you soon.');
        contactForm.reset();
    });

    // Notification functionality
    const notificationBtn = document.getElementById('notificationBtn');
    const notificationDropdown = document.getElementById('notificationDropdown');
    
    if (notificationBtn && notificationDropdown) {
        // Toggle notification dropdown
        notificationBtn.addEventListener('click', function(e) {
            e.stopPropagation();
            notificationDropdown.classList.toggle('show');
            
            // Hide profile dropdown if open
            dropdownMenu.classList.remove('show');
            
        });
           // Close dropdown when clicking outside
           document.addEventListener('click', function() {
        dropdownMenu.classList.remove('show');
    });

        // Mark all as read functionality
        const markAllRead = document.querySelector('.mark-all-read');
        if (markAllRead) {
            markAllRead.addEventListener('click', function() {
                const unreadItems = document.querySelectorAll('.notification-item.unread');
                const badge = document.querySelector('.notification-badge');
                
                unreadItems.forEach(item => {
                    item.classList.remove('unread');
                });
                
                if (badge) {
                    badge.textContent = '0';
                    badge.style.display = 'none';
                }
            });
        }
    }
});

// Carousel functionality
let currentSlide = 0;
let slideInterval;
const slides = document.querySelectorAll('.carousel-images img');
const dots = document.querySelectorAll('.dot');
const totalSlides = slides.length;

function showSlide(n) {
    // Reset all slides and dots
    slides.forEach(slide => slide.classList.remove('active'));
    dots.forEach(dot => dot.classList.remove('active'));
    
    // Handle wrap-around for slides
    currentSlide = (n + totalSlides) % totalSlides;
    
    // Show current slide and dot
    slides[currentSlide].classList.add('active');
    dots[currentSlide].classList.add('active');
}

function nextSlide() {
    showSlide(currentSlide + 1);
}

function prevSlide() {
    showSlide(currentSlide - 1);
}

function goToSlide(n) {
    showSlide(n);
}

function startCarousel() {
    slideInterval = setInterval(nextSlide, 5000);
}

function resetCarouselTimer() {
    clearInterval(slideInterval);
    startCarousel();
}

function initCarousel() {
    showSlide(0);
    startCarousel();
    
    // Pause on hover
    const carousel = document.querySelector('.carousel');
    carousel.addEventListener('mouseenter', () => {
        clearInterval(slideInterval);
    });
    
    carousel.addEventListener('mouseleave', () => {
        startCarousel();
    });
    
    // Dot navigation
    dots.forEach((dot, index) => {
        dot.addEventListener('click', () => {
            goToSlide(index);
            resetCarouselTimer();
        });
    });
    
    // Button navigation
    document.querySelector('.prev').addEventListener('click', () => {
        prevSlide();
        resetCarouselTimer();
    });
    
    document.querySelector('.next').addEventListener('click', () => {
        nextSlide();
        resetCarouselTimer();
    });
}

function logout() {
    // Clear any session data or tokens
    localStorage.removeItem('isLoggedIn');
    // Redirect to login page
    window.location.href = 'index.php';
}