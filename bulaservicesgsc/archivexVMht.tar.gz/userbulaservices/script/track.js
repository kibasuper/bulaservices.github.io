// Sample data - in a real app, this would come from an API
const requests = [
    {
        id: "BC-2025-00145",
        type: "Barangay Clearance",
        status: "pending",
        submitted: "Oct 15, 2025",
        updated: "Oct 16, 2025",
        estimated: "Oct 20, 2025",
        officer: "Juan Dela Cruz",
        documents: [
            { name: "Valid ID.pdf", type: "pdf" },
            { name: "Proof of Residence.jpg", type: "image" }
        ],
        timeline: [
            { date: "Oct 15, 2025 - 2:30 PM", content: "Request submitted online" },
            { date: "Oct 16, 2025 - 9:15 AM", content: "Request received and under review" }
        ]
    },
    {
        id: "BP-2025-00328",
        type: "Business Permit",
        status: "processing",
        submitted: "Oct 10, 2025",
        updated: "Oct 14, 2025",
        estimated: "Oct 18, 2025",
        officer: "Maria Santos",
        documents: [
            { name: "Business Registration.pdf", type: "pdf" },
            { name: "Lease Agreement.pdf", type: "pdf" },
            { name: "Business Location.jpg", type: "image" }
        ],
        timeline: [
            { date: "Oct 10, 2025 - 10:45 AM", content: "Request submitted online" },
            { date: "Oct 11, 2025 - 8:30 AM", content: "Initial review completed" },
            { date: "Oct 12, 2025 - 2:15 PM", content: "Site inspection scheduled" },
            { date: "Oct 14, 2025 - 11:00 AM", content: "Site inspection completed" }
        ]
    },
    {
        id: "CTC-2025-00972",
        type: "Community Tax Certificate (Cedula)",
        status: "completed",
        submitted: "Oct 5, 2025",
        updated: "Oct 7, 2025",
        completed: "Oct 7, 2025",
        officer: "Roberto Gonzales",
        reference: "CT-2025-8472",
        documents: [
            { name: "Community Tax Certificate.pdf", type: "pdf" }
        ],
        timeline: [
            { date: "Oct 5, 2025 - 3:20 PM", content: "Request submitted online" },
            { date: "Oct 6, 2025 - 9:00 AM", content: "Payment verified" },
            { date: "Oct 7, 2025 - 10:30 AM", content: "Certificate issued and ready for pickup" },
            { date: "Oct 7, 2025 - 2:45 PM", content: "Certificate picked up" }
        ]
    },
    {
        id: "CI-2025-00561",
        type: "Certificate of Indigency",
        status: "rejected",
        submitted: "Oct 8, 2025",
        updated: "Oct 10, 2025",
        rejected: "Oct 10, 2025",
        officer: "Juan Dela Cruz",
        reason: "Incomplete supporting documents",
        documents: [
            { name: "Valid ID.pdf", type: "pdf" }
        ],
        timeline: [
            { date: "Oct 8, 2025 - 11:15 AM", content: "Request submitted online" },
            { date: "Oct 9, 2025 - 3:00 PM", content: "Initial review - documents incomplete" },
            { date: "Oct 10, 2025 - 9:30 AM", content: "Request rejected due to missing documents" }
        ]
    }
];

// Render requests
function renderRequests(filterStatus = "All Statuses", searchTerm = "") {
    const container = document.getElementById('requests-list');
    container.innerHTML = '';

    const filteredRequests = requests.filter(request => {
        const matchesStatus = filterStatus === "All Statuses" || 
                            request.status === filterStatus.toLowerCase();
        const matchesSearch = JSON.stringify(request).toLowerCase().includes(searchTerm.toLowerCase());
        return matchesStatus && matchesSearch;
    });

    document.querySelector('.request-count strong').textContent = filteredRequests.length;

    filteredRequests.forEach(request => {
        const progressWidth = {
            pending: "30%",
            processing: "60%",
            completed: "100%",
            rejected: "100%"
        };

        const statusBadgeClass = {
            pending: "pending",
            processing: "processing",
            completed: "completed",
            rejected: "rejected"
        };

        const statusText = {
            pending: "Pending",
            processing: "Processing",
            completed: "Completed",
            rejected: "Rejected"
        };

        const progressColor = {
            pending: "var(--secondary)",
            processing: "var(--primary)",
            completed: "var(--success)",
            rejected: "var(--danger)"
        };

        const requestCard = document.createElement('div');
        requestCard.className = 'request-card';
        requestCard.innerHTML = `
            <div class="request-summary">
                <div class="request-type">${request.type}</div>
                <div class="request-id">#${request.id}</div>
                <div class="request-date">Submitted: ${request.submitted}</div>
                <div class="request-status">
                    <span class="status-badge ${statusBadgeClass[request.status]}">${statusText[request.status]}</span>
                    <div class="progress-container">
                        <div class="progress-bar">
                            <div class="progress" style="width: ${progressWidth[request.status]}; background-color: ${progressColor[request.status]}"></div>
                        </div>
                        <span>${request.status === 'rejected' ? 'Closed' : progressWidth[request.status]}</span>
                    </div>
                </div>
            </div>
            
            <div class="request-details">
                <div class="details-content">
                    <div class="details-grid">
                        <div class="detail-item">
                            <h3>Submission Date</h3>
                            <p>${request.submitted}</p>
                        </div>
                        ${request.completed ? `
                        <div class="detail-item">
                            <h3>Completed On</h3>
                            <p>${request.completed}</p>
                        </div>
                        ` : request.rejected ? `
                        <div class="detail-item">
                            <h3>Rejected On</h3>
                            <p>${request.rejected}</p>
                        </div>
                        ` : `
                        <div class="detail-item">
                            <h3>Last Updated</h3>
                            <p>${request.updated}</p>
                        </div>
                        `}
                        ${request.estimated ? `
                        <div class="detail-item">
                            <h3>Estimated Completion</h3>
                            <p>${request.estimated}</p>
                        </div>
                        ` : ''}
                        <div class="detail-item">
                            <h3>Assigned Officer</h3>
                            <p>${request.officer}</p>
                        </div>
                        ${request.reference ? `
                        <div class="detail-item">
                            <h3>Reference Number</h3>
                            <p>${request.reference}</p>
                        </div>
                        ` : ''}
                        ${request.reason ? `
                        <div class="detail-item">
                            <h3>Reason for Rejection</h3>
                            <p>${request.reason}</p>
                        </div>
                        ` : ''}
                    </div>

                    <div class="documents-list">
                        <h3>${request.status === 'completed' ? 'Issued Document' : 'Submitted Documents'}</h3>
                        <div class="documents-grid">
                            ${request.documents.map(doc => `
                            <div class="document-item">
                                <i class="fas fa-file-${doc.type === 'pdf' ? 'pdf' : doc.type === 'image' ? 'image' : 'alt'}"></i>
                                <span>${doc.name}</span>
                            </div>
                            `).join('')}
                        </div>
                    </div>

                    <div class="timeline">
                        <h3>Processing Timeline</h3>
                        ${request.timeline.map(item => `
                        <div class="timeline-item">
                            <div class="timeline-date">${item.date}</div>
                            <div class="timeline-content">${item.content}</div>
                        </div>
                        `).join('')}
                    </div>

                    <div class="request-actions">
                        ${request.status === 'completed' ? `
                        <button class="action-btn primary">
                            <i class="fas fa-print"></i> Print Certificate
                        </button>
                        <button class="action-btn secondary">
                            <i class="fas fa-download"></i> Download Copy
                        </button>
                        ` : request.status === 'rejected' ? `
                        <button class="action-btn secondary">
                            <i class="fas fa-redo"></i> Resubmit Application
                        </button>
                        <button class="action-btn secondary">
                            <i class="fas fa-question-circle"></i> Request Assistance
                        </button>
                        ` : `
                        <button class="action-btn primary">
                            <i class="fas fa-print"></i> Print Receipt
                        </button>
                        ${request.status === 'pending' ? `
                        <button class="action-btn danger">
                            <i class="fas fa-times"></i> Cancel Request
                        </button>
                        ` : `
                        <button class="action-btn secondary">
                            <i class="fas fa-envelope"></i> Message Officer
                        </button>
                        `}
                        `}
                    </div>
                </div>
            </div>
        `;

        container.appendChild(requestCard);
    });

    // Add click handlers for all request cards
    document.querySelectorAll('.request-card').forEach(card => {
        card.addEventListener('click', function(e) {
            // Don't toggle if clicking on a button or link
            if (!e.target.closest('.action-btn') && !e.target.closest('a')) {
                this.classList.toggle('expanded');
            }
        });
    });

    // Add action button handlers
    document.querySelectorAll('.action-btn').forEach(btn => {
        btn.addEventListener('click', function(e) {
            e.stopPropagation();
            const action = this.textContent.trim();
            
            if (action.includes('Print')) {
                alert('Print functionality would be implemented here');
            } else if (action.includes('Cancel')) {
                if (confirm('Are you sure you want to cancel this request?')) {
                    alert('Request cancellation would be processed');
                }
            } else if (action.includes('Download')) {
                alert('Download would start here');
            } else if (action.includes('Resubmit')) {
                alert('Redirecting to resubmission form');
            } else if (action.includes('Message')) {
                alert('Opening message interface');
            } else if (action.includes('Assistance')) {
                alert('Redirecting to assistance form');
            }
        });
    });
}

// Initialize the page
document.addEventListener('DOMContentLoaded', () => {
    renderRequests();

    // Filter functionality
    document.getElementById('filter-status').addEventListener('change', function() {
        const searchTerm = document.querySelector('.search-box input').value;
        renderRequests(this.value, searchTerm);
    });

    // Search functionality
    document.querySelector('.search-box input').addEventListener('input', function() {
        const filterStatus = document.getElementById('filter-status').value;
        renderRequests(filterStatus, this.value);
    });

    // Sort functionality
    document.getElementById('sort-by').addEventListener('change', function() {
        alert('Sorting would be implemented here based on: ' + this.value);
        // Actual implementation would sort the requests array before rendering
    });
});