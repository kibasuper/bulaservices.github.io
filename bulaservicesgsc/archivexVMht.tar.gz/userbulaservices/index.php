<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

require_once __DIR__ . '/server/config.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Barangay Bula - Login</title>
    <link rel="preload" href="./pics/bula.png" as="image">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="./style/index.css">
</head>
<body>

<?php if (isset($_SESSION['registration_success']) && $_SESSION['registration_success']): ?>
        <div class="success-dialog" data-email="<?= htmlspecialchars($_SESSION['registered_email'] ?? '') ?>">
            <div class="dialog-content">
                <i class="fas fa-check-circle success-icon"></i>
                <h3>Registration Successful!</h3>
                <p>Your account has been created successfully.</p>
                <p>You can now login using your credentials.</p>
                <button class="btn" id="closeSuccessDialog">OK</button>
            </div>
        </div>
        <?php unset($_SESSION['registration_success'], $_SESSION['registered_email']); ?>
    <?php endif; ?>

    <div class="auth-container" id="authContainer">
        <div class="auth-header">
            <div class="auth-logo">
                <img src="./pics/logo.png" alt="Barangay Bula Logo">
            </div>
            <h1 class="auth-title">Barangay Bula<br>Modern Services Portal</h1>
        </div>
        
        <div class="tabs">
            <div class="tab active" data-tab="login">Login</div>
            <div class="tab" data-tab="register" id="registerTab">Register</div>
        </div>
        
        <div class="auth-body">
            <!-- Login Form -->
            <div class="tab-content active" id="login">
                <form id="loginForm" method="POST">
                    <?php if (isset($loginError)): ?>
                        <div class="alert alert-danger"><?= htmlspecialchars($loginError) ?></div>
                    <?php endif; ?>
                    
                    <div class="form-group">
                        <label for="loginEmail">Email</label>
                        <input type="email" id="loginEmail" name="email" class="form-control" required>
                    </div>
                    
                    <div class="form-group">
                        <label for="loginPassword">Password</label>
                        <input type="password" id="loginPassword" name="password" class="form-control" required>
                    </div>
                    
                    <button type="submit" name="login" class="btn">Login</button>
                </form>
            </div>
            
            <!-- Registration Form -->
            <div class="tab-content" id="register">
                <form id="registerForm" method="POST" enctype="multipart/form-data">
                    <?php if (isset($registerError)): ?>
                        <div class="alert alert-danger"><?= htmlspecialchars($registerError) ?></div>
                    <?php endif; ?>
                    
                        <!-- Resident Status -->
                        <div class="form-section resident-status-section">
                            <div class="form-row">
                                <div class="form-group resident-status-container">
                                    <h3 class="resident-status-title">Are you a resident of Barangay Bula?</h3>
                                    <div class="radio-group resident-status-options">
                                        <label class="resident-option"><input type="radio" name="resident_status" value="resident" checked> 
                                            <span class="radio-custom"></span>
                                            <span class="radio-label">Yes, I'm a resident</span>
                                        </label>
                                        <label class="resident-option"><input type="radio" name="resident_status" value="outsider">
                                            <span class="radio-custom"></span>
                                            <span class="radio-label">No, I'm an outsider</span>
                                        </label>
                                    </div>
                                    <div class="form-note resident-status-note">Note: Outsiders can only access facility services (e.g., gymnasium reservation)</div>
                                </div>
                            </div>
                        </div>
                        
                        <!-- Personal Information -->
                        <div class="form-section">
                            <div class="form-row">
                                <div class="form-group">
                                    <label for="firstName">First name</label>
                                    <input type="text" id="firstName" name="first_name" placeholder="Enter First name" required>
                                </div>
                                <div class="form-group">
                                    <label for="middleName">Middle name</label>
                                    <input type="text" id="middleName" name="middle_name" placeholder="Enter Middle name">
                                </div>
                            </div>
                            
                            <div class="form-row">
                                <div class="form-group">
                                    <label for="lastName">Last name</label>
                                    <input type="text" id="lastName" name="last_name" placeholder="Enter Last name" required>
                                </div>
                                <div class="form-group">
                                    <label for="suffix">Suffix</label>
                                    <select id="suffix" name="suffix">
                                        <option value="">None</option>
                                        <option value="Jr">Jr</option>
                                        <option value="Sr">Sr</option>
                                        <option value="II">II</option>
                                        <option value="III">III</option>
                                        <option value="IV">IV</option>
                                    </select>
                                </div>
                            </div>
                            
                            <div class="form-row resident-only-field">
                                <div class="form-group">
                                    <label for="birthPlace">Place of Birth</label>
                                    <input type="text" id="birthPlace" name="birth_place" placeholder="Enter Birthplace">
                                </div>
                                <div class="form-group">
                                    <label for="birthDate">Birthdate</label>
                                    <input type="text" id="birthDate" name="birth_date" placeholder="mm/dd/yyyy" onfocus="this.type='date'" onblur="if(!this.value) this.type='text'">
                                </div>
                            </div>
                            
                            <div class="form-row resident-only-field">
                                <div class="form-group">
                                    <label for="age">Age</label>
                                    <input type="number" id="age" name="age" placeholder="Enter Age">
                                </div>
                                <div class="form-group">
                                    <label for="civilStatus">Civil Status</label>
                                    <select id="civilStatus" name="civil_status">
                                        <option value="">Select Civil Status</option>
                                        <option value="single">Single</option>
                                        <option value="married">Married</option>
                                        <option value="widowed">Widowed</option>
                                        <option value="separated">Separated</option>
                                    </select>
                                </div>
                            </div>
                        
                        <!-- Contact Information -->
                        <div class="form-section">
                            <div class="form-row">
                                <div class="form-group">
                                    <label for="gender">Sex</label>
                                    <select id="gender" name="gender">
                                        <option value="">Select Sex</option>
                                        <option value="male">Male</option>
                                        <option value="female">Female</option>
                                    </select>
                                </div>
                                <div class="form-group resident-only-field">
                                    <label for="purok">Purok</label>
                                    <select id="purok" name="purok">
                                        <option value="">Select Purok No.</option>
                                        <option value="1">Purok 1</option>
                                        <option value="2">Purok 2</option>
                                        <option value="3">Purok 3</option>
                                        <option value="4">Purok 4</option>
                                        <option value="5">Purok 5</option>
                                        <option value="6">Purok 6</option>
                                        <option value="7">Purok 7</option>
                                        <option value="8">Purok 8</option>
                                        <option value="9">Purok 9</option>
                                        <option value="10">Purok 10</option>
                                        <option value="11">Purok 11</option>
                                        <option value="12">Purok 12</option>
                                        <option value="13">Purok 13</option>
                                        <option value="14">Purok 14</option>
                                        <option value="15">Purok 15</option>
                                        <option value="16">Purok 16</option>
                                        <option value="17">Purok 17</option>
                                        <option value="18">Purok 18</option>
                                        <option value="19">Purok 19</option>
                                        <option value="20">Purok 20</option>
                                        <option value="21">Purok 21</option>
                                        <option value="22">Purok 22</option>
                                        <option value="23">Purok 23</option>
                                        <option value="24">Purok 24</option>
                                        <option value="25">Purok 25</option>
                                    </select>
                                </div>
                            </div>
                            
                            <div class="form-group resident-only-field">
                                    <label for="yearStartedStaying">Year Started Staying in Barangay</label>
                                    <select id="yearStartedStaying" name="year_started_staying">
                                        <option value="">Select Year</option>
                                        <?php 
                                        $currentYear = date("Y");
                                        for ($year = $currentYear; $year >= 1900; $year--) {
                                            echo "<option value='$year'>$year</option>";
                                        }
                                        ?>
                                    </select>
                            </div>
                            
                            <div class="form-row">
                                <div class="form-group">
                                    <label for="contact">Contact Number</label>
                                    <input type="text" id="contact" name="contact_number" placeholder="Enter Contact Number" required>
                                </div>
                            </div>
                            
                            <div class="form-row">
                                <div class="form-group resident-only-field">
                                    <label for="occupation">Occupation</label>
                                    <input type="text" id="occupation" name="occupation" placeholder="Enter Occupation">
                                </div>
                            </div>
                        </div>
                        
                        <!-- Account Information -->
                        <div class="form-section">
                            <div class="form-row">
                                <div class="form-group">
                                    <label for="address">Address</label>
                                    <input type="text" id="address" name="address" placeholder="Enter Address" required>
                                </div>
                            </div>

                            <div class="form-group">
                                    <label for="email">Email Address</label>
                                    <input type="email" id="email" name="email" placeholder="Enter Email" required>
                            </div>
                            
                            <div class="form-row">                              
                                <div class="form-group">
                                    <label for="username">Username</label>
                                    <input type="text" id="username" name="username" placeholder="Username" required>
                                </div>
                                <div class="form-group">
                                    <label for="password">Password</label>
                                    <input type="password" id="password" name="password" placeholder="Password" required>
                                </div>
                            </div>
                            
                            <div class="form-row">
                                <div class="form-group">
                                    <label for="confirmPassword">Confirm Password</label>
                                    <input type="password" id="confirmPassword" name="confirm_password" placeholder="Confirm Password" required>
                                </div>
                            </div>                       
                        </div>

                        <!-- Profile Picture Section (updated) -->
                        <div class="profile-picture-section">
                            <h3 style="text-align: center; margin-bottom: 15px;">Profile Picture</h3>
                            <div class="profile-picture-container">
                                <div class="profile-picture-preview">
                                    <img src="./pics/profile-placeholder.jpg" alt="Profile Picture" id="profileImage">
                                </div>
                                
                                <div class="profile-picture-options">
                                    <label class="profile-picture-btn" for="profilePictureInput">
                                        <i class="fas fa-upload"></i>
                                        <span>Upload Photo</span>
                                        <input type="file" id="profilePictureInput" name="profile_picture" accept="image/*">
                                    </label>
                                    
                                    <button type="button" class="profile-picture-btn" id="takePhotoBtn">
                                        <i class="fas fa-camera"></i>
                                        <span>Take Photo</span>
                                    </button>
                                </div>
                            </div>
                        </div>
                                            
                        <div class="register-actions">
                            <button type="submit" name="register" class="btn btn-register">Register</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <script src="./script/index.js">
    </script>
</body>
</html>