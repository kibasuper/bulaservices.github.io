<?php
/**
 * User Configuration File
 * 
 * Central configuration and initialization for user-facing functionality
 */

// Strict types for better type safety
declare(strict_types=1);

// Error reporting configuration
error_reporting(E_ALL);
ini_set('display_errors', '0'); // Disable in production
ini_set('log_errors', '1');
ini_set('error_log', __DIR__ . '/../../logs/user_errors.log');

// Include required files
require_once __DIR__ . '/../../server/db_connection.php';
require_once __DIR__ . '/../../server/auth_functions.php';

// Base URL configurations
define('ADMIN_BASE_URL', '/bulaservicesgsc/adminbulaservices/');
define('USER_BASE_URL', '/bulaservicesgsc/userbulaservices/');
define('BASE_PATH', realpath(__DIR__ . '/../'));

// Application settings
define('MAX_LOGIN_ATTEMPTS', 5);
define('LOGIN_LOCKOUT_TIME', 15 * 60); // 15 minutes in seconds
define('SESSION_TIMEOUT', 1800); // 30 minutes in seconds

// Content Security Policy Header (adjust as needed)
header("Content-Security-Policy: default-src 'self'; script-src 'self' 'unsafe-inline'; style-src 'self' 'unsafe-inline'; img-src 'self' data:;");

// Security headers
header("X-Frame-Options: DENY");
header("X-Content-Type-Options: nosniff");
header("Referrer-Policy: strict-origin-when-cross-origin");

/**
 * Verify user access with multiple security checks
 */
function ensureUserAccess(): void {
    // Check if user is logged in
    if (!isLoggedIn()) {
        $_SESSION['login_redirect'] = $_SERVER['REQUEST_URI'];
        redirect('index.php');
    }

    // Check session timeout
    if (isset($_SESSION['last_activity']) && (time() - $_SESSION['last_activity'] > SESSION_TIMEOUT)) {
        session_unset();
        session_destroy();
        redirect('index.php?timeout=1');
    }

    // Update last activity time
    $_SESSION['last_activity'] = time();

    // Verify session consistency
    if (!isset($_SESSION['user_ip']) || $_SESSION['user_ip'] !== $_SERVER['REMOTE_ADDR'] ||
        !isset($_SESSION['user_agent']) || $_SESSION['user_agent'] !== $_SERVER['HTTP_USER_AGENT']) {
        session_unset();
        session_destroy();
        redirect('index.php?security=1');
    }
}

/**
 * Get absolute URL for user-facing pages
 */
function userUrl(string $path = ''): string {
    return USER_BASE_URL . ltrim($path, '/');
}

/**
 * Get absolute URL for admin-facing pages
 */
function adminUrl(string $path = ''): string {
    return ADMIN_BASE_URL . ltrim($path, '/');
}

/**
 * Check if current request is AJAX
 */
function isAjaxRequest(): bool {
    return !empty($_SERVER['HTTP_X_REQUESTED_WITH']) && 
           strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) === 'xmlhttprequest';
}

/**
 * Get current user ID safely
 */
function getCurrentUserId(): ?int {
    return $_SESSION['user_id'] ?? null;
}

// Handle session timeout warning
if (isset($_SESSION['last_activity']) && 
    (time() - $_SESSION['last_activity'] > (SESSION_TIMEOUT - 300))) { // 5 minute warning
    if (!isAjaxRequest() && basename($_SERVER['PHP_SELF']) !== 'logout.php') {
        $_SESSION['show_timeout_warning'] = true;
    }
}