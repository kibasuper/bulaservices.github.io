<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Profile - Barangay Bula</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="./style/profile.css">
</head>
<body>
    <div class="container">
        <div class="profile-card">
            <div class="profile-header">
                <div class="profile-pic-container">
                    <img id="profileImage" src="./pics/profile-placeholder.jpg" alt="Profile Picture" class="profile-pic">
                    <button class="edit-pic-btn" id="editPicBtn">
                        <i class="fas fa-camera"></i>
                    </button>
                    <input type="file" id="profilePicInput" accept="image/*" style="display: none;">
                </div>
                <h1 class="profile-name" id="profileName">Juan M. Dela Cruz</h1>
                <p class="profile-subtitle">Resident of Barangay Bula</p>
            </div>
            
            <div class="profile-content">
                <!-- Left Column - Personal Information -->
                <div>
                    <div class="profile-section">
                        <h2 class="section-title">
                            <i class="fas fa-user-circle"></i> Personal Information
                        </h2>
                        
                        <div class="info-grid">
                            <!-- First Name -->
                            <div class="info-item">
                                <div class="info-label">First Name:</div>
                                <div class="info-value" id="firstNameValue">Juan</div>
                                <button class="edit-btn" onclick="toggleEdit('firstName')">
                                    <i class="fas fa-edit"></i>
                                </button>
                            </div>
                            <div class="edit-form" id="firstNameForm">
                                <div class="form-group">
                                    <label for="firstNameInput">First Name</label>
                                    <input type="text" id="firstNameInput" class="form-control" value="Juan">
                                </div>
                                <div class="form-actions">
                                    <button class="btn btn-primary" onclick="saveField('firstName')">Save</button>
                                    <button class="btn btn-secondary" onclick="cancelEdit('firstName')">Cancel</button>
                                </div>
                            </div>
                            
                            <!-- Middle Name -->
                            <div class="info-item">
                                <div class="info-label">Middle Name:</div>
                                <div class="info-value" id="middleNameValue">Mendoza</div>
                                <button class="edit-btn" onclick="toggleEdit('middleName')">
                                    <i class="fas fa-edit"></i>
                                </button>
                            </div>
                            <div class="edit-form" id="middleNameForm">
                                <div class="form-group">
                                    <label for="middleNameInput">Middle Name</label>
                                    <input type="text" id="middleNameInput" class="form-control" value="Mendoza">
                                </div>
                                <div class="form-actions">
                                    <button class="btn btn-primary" onclick="saveField('middleName')">Save</button>
                                    <button class="btn btn-secondary" onclick="cancelEdit('middleName')">Cancel</button>
                                </div>
                            </div>
                            
                            <!-- Last Name -->
                            <div class="info-item">
                                <div class="info-label">Last Name:</div>
                                <div class="info-value" id="lastNameValue">Dela Cruz</div>
                                <button class="edit-btn" onclick="toggleEdit('lastName')">
                                    <i class="fas fa-edit"></i>
                                </button>
                            </div>
                            <div class="edit-form" id="lastNameForm">
                                <div class="form-group">
                                    <label for="lastNameInput">Last Name</label>
                                    <input type="text" id="lastNameInput" class="form-control" value="Dela Cruz">
                                </div>
                                <div class="form-actions">
                                    <button class="btn btn-primary" onclick="saveField('lastName')">Save</button>
                                    <button class="btn btn-secondary" onclick="cancelEdit('lastName')">Cancel</button>
                                </div>
                            </div>
                            
                            <!-- Place of Birth -->
                            <div class="info-item">
                                <div class="info-label">Place of Birth:</div>
                                <div class="info-value" id="placeOfBirthValue">General Santos City</div>
                                <button class="edit-btn" onclick="toggleEdit('placeOfBirth')">
                                    <i class="fas fa-edit"></i>
                                </button>
                            </div>
                            <div class="edit-form" id="placeOfBirthForm">
                                <div class="form-group">
                                    <label for="placeOfBirthInput">Place of Birth</label>
                                    <input type="text" id="placeOfBirthInput" class="form-control" value="General Santos City">
                                </div>
                                <div class="form-actions">
                                    <button class="btn btn-primary" onclick="saveField('placeOfBirth')">Save</button>
                                    <button class="btn btn-secondary" onclick="cancelEdit('placeOfBirth')">Cancel</button>
                                </div>
                            </div>
                            
                            <!-- Birthdate -->
                            <div class="info-item">
                                <div class="info-label">Birthdate:</div>
                                <div class="info-value" id="birthDateValue">June 15, 1990</div>
                                <button class="edit-btn" onclick="toggleEdit('birthDate')">
                                    <i class="fas fa-edit"></i>
                                </button>
                            </div>
                            <div class="edit-form" id="birthDateForm">
                                <div class="form-group">
                                    <label for="birthDateInput">Birthdate</label>
                                    <input type="date" id="birthDateInput" class="form-control" value="1990-06-15">
                                </div>
                                <div class="form-actions">
                                    <button class="btn btn-primary" onclick="saveField('birthDate')">Save</button>
                                    <button class="btn btn-secondary" onclick="cancelEdit('birthDate')">Cancel</button>
                                </div>
                            </div>
                            
                            <!-- Age (Read-only) -->
                            <div class="info-item">
                                <div class="info-label">Age:</div>
                                <div class="info-value read-only" id="ageValue">33 years old</div>
                            </div>
                            
                            <!-- Sex -->
                            <div class="info-item">
                                <div class="info-label">Sex:</div>
                                <div class="info-value" id="sexValue">Male</div>
                                <button class="edit-btn" onclick="toggleEdit('sex')">
                                    <i class="fas fa-edit"></i>
                                </button>
                            </div>
                            <div class="edit-form" id="sexForm">
                                <div class="form-group">
                                    <label for="sexInput">Sex</label>
                                    <select id="sexInput" class="form-control">
                                        <option value="Male">Male</option>
                                        <option value="Female">Female</option>
                                        <option value="Other">Other</option>
                                    </select>
                                </div>
                                <div class="form-actions">
                                    <button class="btn btn-primary" onclick="saveField('sex')">Save</button>
                                    <button class="btn btn-secondary" onclick="cancelEdit('sex')">Cancel</button>
                                </div>
                            </div>
                            
                            <!-- Civil Status -->
                            <div class="info-item">
                                <div class="info-label">Civil Status:</div>
                                <div class="info-value" id="civilStatusValue">Single</div>
                                <button class="edit-btn" onclick="toggleEdit('civilStatus')">
                                    <i class="fas fa-edit"></i>
                                </button>
                            </div>
                            <div class="edit-form" id="civilStatusForm">
                                <div class="form-group">
                                    <label for="civilStatusInput">Civil Status</label>
                                    <select id="civilStatusInput" class="form-control">
                                        <option value="Single">Single</option>
                                        <option value="Married">Married</option>
                                        <option value="Widowed">Widowed</option>
                                        <option value="Separated">Separated</option>
                                    </select>
                                </div>
                                <div class="form-actions">
                                    <button class="btn btn-primary" onclick="saveField('civilStatus')">Save</button>
                                    <button class="btn btn-secondary" onclick="cancelEdit('civilStatus')">Cancel</button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- Right Column - Residence Information -->
                <div>
                    <div class="profile-section">
                        <h2 class="section-title">
                            <i class="fas fa-home"></i> Residence Information
                        </h2>
                        
                        <div class="info-grid">
                            <!-- Year Started Staying -->
                            <div class="info-item">
                                <div class="info-label">Year Started Staying:</div>
                                <div class="info-value" id="yearStartedValue">2015</div>
                                <button class="edit-btn" onclick="toggleEdit('yearStarted')">
                                    <i class="fas fa-edit"></i>
                                </button>
                            </div>
                            <div class="edit-form" id="yearStartedForm">
                                <div class="form-group">
                                    <label for="yearStartedInput">Year Started Staying</label>
                                    <input type="number" id="yearStartedInput" class="form-control" value="2015" min="1900" max="2025">
                                    <small class="form-text">Enter the year you first became a resident</small>
                                </div>
                                <div class="form-actions">
                                    <button class="btn btn-primary" onclick="saveField('yearStarted')">Save</button>
                                    <button class="btn btn-secondary" onclick="cancelEdit('yearStarted')">Cancel</button>
                                </div>
                            </div>
                            
                            <!-- Contact Number -->
                            <div class="info-item">
                                <div class="info-label">Contact Number:</div>
                                <div class="info-value" id="contactNumberValue">09123456789</div>
                                <button class="edit-btn" onclick="toggleEdit('contactNumber')">
                                    <i class="fas fa-edit"></i>
                                </button>
                            </div>
                            <div class="edit-form" id="contactNumberForm">
                                <div class="form-group">
                                    <label for="contactNumberInput">Contact Number</label>
                                    <input type="tel" id="contactNumberInput" class="form-control" value="09123456789" placeholder="09XXXXXXXXX" pattern="[0-9]{11}">
                                    <small class="form-text">Format: 09XXXXXXXXX (11 digits)</small>
                                </div>
                                <div class="form-actions">
                                    <button class="btn btn-primary" onclick="saveField('contactNumber')">Save</button>
                                    <button class="btn btn-secondary" onclick="cancelEdit('contactNumber')">Cancel</button>
                                </div>
                            </div>
                            
                            <!-- Occupation -->
                            <div class="info-item">
                                <div class="info-label">Occupation:</div>
                                <div class="info-value" id="occupationValue">Fisherman</div>
                                <button class="edit-btn" onclick="toggleEdit('occupation')">
                                    <i class="fas fa-edit"></i>
                                </button>
                            </div>
                            <div class="edit-form" id="occupationForm">
                                <div class="form-group">
                                    <label for="occupationInput">Occupation</label>
                                    <input type="text" id="occupationInput" class="form-control" value="Fisherman">
                                </div>
                                <div class="form-actions">
                                    <button class="btn btn-primary" onclick="saveField('occupation')">Save</button>
                                    <button class="btn btn-secondary" onclick="cancelEdit('occupation')">Cancel</button>
                                </div>
                            </div>
                            
                            <!-- Address -->
                            <div class="info-item">
                                <div class="info-label">Complete Address:</div>
                                <div class="info-value" id="addressValue">123 Bula Street, General Santos City</div>
                                <button class="edit-btn" onclick="toggleEdit('address')">
                                    <i class="fas fa-edit"></i>
                                </button>
                            </div>
                            <div class="edit-form" id="addressForm">
                                <div class="form-group">
                                    <label for="addressInput">Complete Address</label>
                                    <textarea id="addressInput" class="form-control">123 Bula Street, General Santos City</textarea>
                                </div>
                                <div class="form-actions">
                                    <button class="btn btn-primary" onclick="saveField('address')">Save</button>
                                    <button class="btn btn-secondary" onclick="cancelEdit('address')">Cancel</button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- Security Section (Moved to bottom) -->
                <div class="security-section">
                    <h2 class="section-title">
                        <i class="fas fa-lock"></i> Account Security
                    </h2>
                    
                    <div class="form-group">
                        <label for="currentPassword">Current Password</label>
                        <input type="password" id="currentPassword" class="form-control" placeholder="Enter current password">
                    </div>
                    
                    <div class="form-group">
                        <label for="newPassword">New Password</label>
                        <input type="password" id="newPassword" class="form-control" placeholder="Enter new password">
                        <small class="form-text">Minimum 8 characters with at least 1 number</small>
                    </div>
                    
                    <div class="form-group">
                        <label for="confirmPassword">Confirm New Password</label>
                        <input type="password" id="confirmPassword" class="form-control" placeholder="Confirm new password">
                    </div>
                    
                    <button class="btn btn-primary" onclick="changePassword()">
                        <i class="fas fa-key"></i> Change Password
                    </button>
                </div>
                
                <!-- Action Buttons -->
                <div class="profile-actions">
                    <button class="btn btn-secondary btn-lg" onclick="window.location.href='home.php'">
                        <i class="fas fa-arrow-left"></i> Back to Home
                    </button>
                    <button class="btn btn-primary btn-lg" id="saveAllBtn">
                        <i class="fas fa-save"></i> Save All Changes
                    </button>
                </div>
            </div>
        </div>
    </div>

    <script src="./script/profile.js"></script>
</body>
</html>