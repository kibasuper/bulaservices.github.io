<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

require_once __DIR__ . '/../config/config.php';

header('Content-Type: application/json');

$response = [
    'success' => false,
    'message' => 'Debug: Something went wrong',
    'errors' => []
];

// Check if the request method is POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    $response['message'] = 'Invalid request method';
    echo json_encode($response);
    exit;
}

// --- LOGIN HANDLER ---
if (isset($_POST['login'])) {
    try {
        $conn = getDBConnection();

        $email = sanitizeInput($_POST['email'] ?? '');
        $password = $_POST['password'] ?? '';

        if (empty($email) || empty($password)) {
            echo json_encode([
                "success" => false,
                "message" => "Email and password are required"
            ]);
            exit;
        }

        $stmt = $conn->prepare("SELECT id, email, password FROM users WHERE email = ?");
        $stmt->execute([$email]);
        $user = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($user && password_verify($password, $user['password'])) {
            echo json_encode([
                "success" => true,
                "redirect" => "home.php"
            ]);
        } else {
            echo json_encode([
                "success" => false,
                "message" => "Invalid email or password"
            ]);
        }
        exit;

    } catch (Exception $e) {
        echo json_encode([
            "success" => false,
            "message" => "Login error: " . $e->getMessage()
        ]);
        exit;
    }
}

try {
    // Initialize database connection
    $conn = getDBConnection();

    // Sanitize and validate input data
    $userType = sanitizeInput($_POST['resident_status'] ?? '');
    $firstName = sanitizeInput($_POST['first_name'] ?? '');
    $lastName = sanitizeInput($_POST['last_name'] ?? '');
    $email = sanitizeInput($_POST['email'] ?? '');
    $username = sanitizeInput($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';
    $confirmPassword = $_POST['confirm_password'] ?? '';
    $contactNumber = sanitizeInput($_POST['contact_number'] ?? '');
    $address = sanitizeInput($_POST['address'] ?? '');

    // Resident-specific fields
    $middleName = isset($_POST['middle_name']) ? sanitizeInput($_POST['middle_name']) : null;
    $suffix = isset($_POST['suffix']) ? sanitizeInput($_POST['suffix']) : null;
    $birthPlace = ($userType === 'resident') ? sanitizeInput($_POST['birth_place'] ?? '') : null;
    $birthDate = ($userType === 'resident') ? ($_POST['birth_date'] ?? null) : null;
    $age = ($userType === 'resident') ? (int)($_POST['age'] ?? 0) : null;
    $civilStatus = ($userType === 'resident') ? sanitizeInput($_POST['civil_status'] ?? '') : null;
    $gender = ($userType === 'resident') ? sanitizeInput($_POST['gender'] ?? '') : null;
    $purok = ($userType === 'resident') ? sanitizeInput($_POST['purok'] ?? '') : null;
    $yearStartedStaying = ($userType === 'resident') ? (int)($_POST['year_started_staying'] ?? 0) : null;
    $occupation = ($userType === 'resident') ? sanitizeInput($_POST['occupation'] ?? '') : null;

    // Validate required fields
    $requiredFields = [
        'first_name' => $firstName,
        'last_name' => $lastName,
        'email' => $email,
        'username' => $username,
        'password' => $password,
        'confirm_password' => $confirmPassword,
        'contact_number' => $contactNumber,
        'address' => $address
    ];

    foreach ($requiredFields as $field => $value) {
        if (empty($value)) {
            $response['errors'][$field] = ucfirst(str_replace('_', ' ', $field)) . ' is required';
        }
    }

    // Additional validations
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $response['errors']['email'] = 'Invalid email format';
    }

    if ($password !== $confirmPassword) {
        $response['errors']['confirm_password'] = 'Passwords do not match';
    }

    if (strlen($password) < 6) {
        $response['errors']['password'] = 'Password must be at least 6 characters';
    }

    // Check for existing email or username
    $stmt = $conn->prepare("SELECT email, username FROM users WHERE email = ? OR username = ?");
    $stmt->execute([$email, $username]);
    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
        if ($row['email'] === $email) {
            $response['errors']['email'] = 'Email already exists';
        }
        if ($row['username'] === $username) {
            $response['errors']['username'] = 'Username already exists';
        }
    }

    // If there are errors, return them
    if (!empty($response['errors'])) {
        $response['message'] = 'Please correct the errors below';
        echo json_encode($response);
        exit;
    }

    // Handle file upload
    $profilePicture = null;
    if (isset($_FILES['profile_picture']) && $_FILES['profile_picture']['error'] === UPLOAD_ERR_OK) {
        try {
            $profilePicture = uploadProfilePicture($_FILES['profile_picture']);
        } catch (Exception $e) {
            $response['errors']['profile_picture'] = $e->getMessage();
            echo json_encode($response);
            exit;
        }
    }

    // Hash password
    $hashedPassword = hashPassword($password);

    // Insert user into database
    $stmt = $conn->prepare("INSERT INTO users (
        user_type, first_name, middle_name, last_name, suffix, birth_place, birth_date, age,
        civil_status, gender, purok, year_started_staying, contact_number, occupation,
        address, email, username, password, profile_picture
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");

    $stmt->execute([
        $userType, $firstName, $middleName, $lastName, $suffix, $birthPlace, $birthDate, $age,
        $civilStatus, $gender, $purok, $yearStartedStaying, $contactNumber, $occupation,
        $address, $email, $username, $hashedPassword, $profilePicture
    ]);

    // Success response
    $response['success'] = true;
    $response['message'] = 'Registration successful! You can now login.';

} catch (PDOException $e) {
    // Database error handling
    $response['message'] = 'Database error: ' . $e->getMessage();
    error_log("PDO Exception: " . $e->getMessage());
} catch (Exception $e) {
    // General error handling
    $response['message'] = $e->getMessage();
    error_log("Exception: " . $e->getMessage());
}

echo json_encode($response);
exit;
