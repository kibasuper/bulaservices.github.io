<?php
/**
 * TEMPORARY SIMPLIFIED CONFIGURATION
 * Focused only on basic login functionality
 */

// Basic error reporting
error_reporting(E_ALL);
ini_set('display_errors', '1'); // Enabled for debugging
ini_set('log_errors', '1');
ini_set('error_log', __DIR__ . '/../../logs/user_errors.log');

// Database and auth requirements (keep these)
require_once __DIR__ . '/../../server/db_connection.php';
require_once __DIR__ . '/../../server/auth_functions.php';

// Base URLs (keep these)
define('USER_BASE_URL', '/bulaservicesgsc/userbulaservices/');

/* COMMENTED OUT TEMPORARILY - SECURITY HEADERS
header("Content-Security-Policy: default-src 'self'; script-src 'self' 'unsafe-inline'; style-src 'self' 'unsafe-inline'; img-src 'self' data:;");
header("X-Frame-Options: DENY");
header("X-Content-Type-Options: nosniff");
header("Referrer-Policy: strict-origin-when-cross-origin");
*/

// Session configuration (simplified)
session_start();

/* COMMENTED OUT TEMPORARILY - ADVANCED SESSION CHECKS
function ensureUserAccess(): void {
    if (!isLoggedIn()) {
        $_SESSION['login_redirect'] = $_SERVER['REQUEST_URI'];
        redirect('index.php');
    }
    $_SESSION['last_activity'] = time();
}
*/

// Basic URL function (keep)
function userUrl(string $path = ''): string {
    return USER_BASE_URL . ltrim($path, '/');
}

/* COMMENTED OUT TEMPORARILY - CSRF PROTECTION
function csrfField(): string {
    $token = bin2hex(random_bytes(32));
    $_SESSION['csrf_token'] = $token;
    return '<input type="hidden" name="csrf_token" value="' . htmlspecialchars($token, ENT_QUOTES) . '">';
}

if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}
*/

// Basic user ID check (keep)
function getCurrentUserId(): ?int {
    return $_SESSION['user_id'] ?? null;
}