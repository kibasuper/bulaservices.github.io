<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Requests - Barangay Bula</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="./style/track.css">
</head>
<body>
    <!-- Reused Navbar -->
    <nav class="navbar">
        <a href="home.php" class="logo">
            <img src="./pics/logo.png" alt="Barangay Logo">
            <span class="logo-text">Barangay Bula</span>
        </a>
    </nav>

    <!-- Tracker Content -->
    <div class="tracker-container">
        <div class="tracker-header">
            <h1>My Requests</h1>
            <div class="request-count">Showing <strong>4</strong> requests</div>
        </div>

        <div class="tracker-controls">
            <div class="filter-group">
                <label for="sort-by">Sort by:</label>
                <select id="sort-by">
                    <option>Newest First</option>
                    <option>Oldest First</option>
                    <option>Request Type (A-Z)</option>
                    <option>Request Type (Z-A)</option>
                    <option>Status</option>
                </select>
            </div>

            <div class="filter-group">
                <label for="filter-status">Filter by:</label>
                <select id="filter-status">
                    <option>All Statuses</option>
                    <option>Pending</option>
                    <option>Processing</option>
                    <option>Completed</option>
                    <option>Rejected</option>
                </select>
            </div>

            <div class="search-box">
                <i class="fas fa-search"></i>
                <input type="text" placeholder="Search requests...">
            </div>
        </div>

        <div class="requests-list" id="requests-list">
            <!-- Requests will be dynamically inserted here -->
        </div>
    </div>

    <script src="./script/track.js"></script>
</body>
</html>